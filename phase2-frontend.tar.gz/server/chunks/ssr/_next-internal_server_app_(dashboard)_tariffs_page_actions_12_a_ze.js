module.exports=[71776,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28dashboard%29_tariffs_page_actions_12_a_ze.js.map