module.exports=[83304,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28dashboard%29_chargers_page_actions_1lpek6w.js.map