module.exports=[5093,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28dashboard%29_financial_page_actions_020w6hd.js.map