module.exports=[54406,a=>{"use strict";var b=a.i(7997);a.s(["default",0,function({children:a}){return(0,b.jsx)(b.Fragment,{children:a})}])},13325,function(a){a.n(a.i(54406))}];

//# sourceMappingURL=src_app_%28public%29_layout_tsx_1u8p-3t._.js.map