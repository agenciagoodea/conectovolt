module.exports=[67429,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28dashboard%29_vehicles_page_actions_1fqjud3.js.map