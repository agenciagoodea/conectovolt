module.exports=[15581,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_portal_history_page_actions_02hh6rr.js.map