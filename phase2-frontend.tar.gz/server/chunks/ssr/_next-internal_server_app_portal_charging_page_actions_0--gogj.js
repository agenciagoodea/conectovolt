module.exports=[11434,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_portal_charging_page_actions_0--gogj.js.map