module.exports=[68666,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_portal_profile_page_actions_1bnm8d0.js.map