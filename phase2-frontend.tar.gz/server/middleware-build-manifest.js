globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/cUhS5gaXy4VbpU_6vaLoW/_buildManifest.js",
    "static/cUhS5gaXy4VbpU_6vaLoW/_ssgManifest.js",
    "static/cUhS5gaXy4VbpU_6vaLoW/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3s6nzrbk-8mnv.js",
    "static/chunks/19mx3mg6lkumu.js",
    "static/chunks/4561u0v7ysn3r.js",
    "static/chunks/449hr59l03kqu.js",
    "static/chunks/turbopack-1fm76r5ook-xo.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
